# بناء APK من الهاتف فقط

هذا المشروع مجهز للبناء على Codemagic عبر الملف `codemagic.yaml`.

## الناتج
سيتم إنشاء APK قابل للتثبيت من:
`app/build/outputs/apk/debug/`

## ملاحظة
هذه نسخة Debug للتجربة على الهاتف. قبل النشر في Google Play يجب إعداد توقيع Release/Keystore خاص بالتطبيق.
