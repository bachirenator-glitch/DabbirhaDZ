package dz.dabbirha.app

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private val Green=Color(0xFF008B68); private val Deep=Color(0xFF006B52); private val Mint=Color(0xFFE9F7F2)
private val Ink=Color(0xFF17352D); private val Muted=Color(0xFF71817B); private val Red=Color(0xFFE35D50); private val Orange=Color(0xFFFFB72B)
private fun money(n:Long)=NumberFormat.getIntegerInstance(Locale("ar","DZ")).format(n)+" دج"
private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())

data class Tx(val id:Long=System.currentTimeMillis(),val title:String,val category:String,val amount:Long,val income:Boolean,val date:String=today())
data class Debt(val id:Long=System.currentTimeMillis(),val name:String,val amount:Long,val due:String)
data class Goal(val id:Long=System.currentTimeMillis(),val name:String,val target:Long,val saved:Long)

enum class Screen{Home,Transactions,Budget,Reports,More}

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{DabbirhaApp(this)}}
}

class Store(private val c:Context){
 private val p=c.getSharedPreferences("dabbirha",Context.MODE_PRIVATE)
 fun loadTx():MutableList<Tx>{val a=JSONArray(p.getString("tx","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Tx(o.getLong("id"),o.getString("title"),o.getString("cat"),o.getLong("amt"),o.getBoolean("income"),o.getString("date"))}}
 fun saveTx(x:List<Tx>){val a=JSONArray();x.forEach{a.put(JSONObject().apply{put("id",it.id);put("title",it.title);put("cat",it.category);put("amt",it.amount);put("income",it.income);put("date",it.date)})};p.edit().putString("tx",a.toString()).apply()}
 fun budget():Long=p.getLong("budget",65000); fun setBudget(v:Long)=p.edit().putLong("budget",v).apply()
}

@Composable fun DabbirhaApp(ctx:Context){
 CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){
  val store=remember{Store(ctx)}; val txs=remember{mutableStateListOf<Tx>()}; LaunchedEffect(Unit){if(txs.isEmpty())txs.addAll(store.loadTx())}
  var screen by remember{mutableStateOf(Screen.Home)}; var dialog by remember{mutableStateOf(false)}; var incomeDialog by remember{mutableStateOf(false)}
  MaterialTheme(colorScheme=lightColorScheme(primary=Green,secondary=Orange,background=Color(0xFFF6FAF8),surface=Color.White,onSurface=Ink)){
   Scaffold(bottomBar={BottomBar(screen){screen=it}}){pad->Box(Modifier.fillMaxSize().padding(pad)){
    when(screen){Screen.Home->Home(txs,store.budget(),{dialog=true},{incomeDialog=true});Screen.Transactions->Transactions(txs);Screen.Budget->Budget(store.budget()){v->store.setBudget(v)};Screen.Reports->Reports(txs,store.budget());Screen.More->More(ctx)}
    if(dialog)EntryDialog(false,{dialog=false}){t->txs.add(0,t);store.saveTx(txs);dialog=false}
    if(incomeDialog)EntryDialog(true,{incomeDialog=false}){t->txs.add(0,t);store.saveTx(txs);incomeDialog=false}
   }}
  }
 }
}

@Composable fun Header(){Row(Modifier.fillMaxWidth().padding(20.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("دبّرها DZ",color=Green,fontSize=27.sp,fontWeight=FontWeight.ExtraBold);Text("إدارة أموالك ببساطة",color=Muted,fontSize=13.sp)}Surface(color=Mint,shape=CircleShape){Icon(Icons.Default.AccountCircle,null,tint=Green,modifier=Modifier.padding(8.dp).size(30.dp))}}}

@Composable fun Home(txs:List<Tx>,budget:Long,onExpense:()->Unit,onIncome:()->Unit){
 val inc=txs.filter{it.income}.sumOf{it.amount};val exp=txs.filter{!it.income}.sumOf{it.amount};val bal=inc-exp;val remaining=(budget-exp).coerceAtLeast(0);val daily=remaining/30
 LazyColumn(contentPadding=PaddingValues(bottom=28.dp)){item{Header()};item{Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(),shape=RoundedCornerShape(26.dp),colors=CardDefaults.cardColors(containerColor=Deep)){Column(Modifier.padding(22.dp)){Text("المتاح هذا الشهر",color=Color.White.copy(.78f));Text(money(bal),color=Color.White,fontSize=32.sp,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(14.dp));LinearProgressIndicator(progress={(exp.toFloat()/budget.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),color=Orange,trackColor=Color.White.copy(.18f));Spacer(Modifier.height(7.dp));Text(if(exp<=budget)"أنت ضمن ميزانيتك 👍" else "تجاوزت الميزانية، راجع مصاريفك",color=Color.White,fontWeight=FontWeight.SemiBold)}}};item{Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("الدخل",money(inc),Green,Modifier.weight(1f));Stat("المصاريف",money(exp),Red,Modifier.weight(1f));Stat("اليومي",money(daily),Orange,Modifier.weight(1f))}};item{Section("مصروفاتك حسب الفئة")};
  val groups=txs.filter{!it.income}.groupBy{it.category}.entries.sortedByDescending{it.value.sumOf{t->t.amount}}.take(5);items(groups){(cat,list)->Category(cat,list.sumOf{it.amount},exp)}
  item{Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick=onExpense,modifier=Modifier.weight(1f).height(52.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.Remove,null);Text("مصروف")};OutlinedButton(onClick=onIncome,modifier=Modifier.weight(1f).height(52.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.Add,null);Text("دخل")}}}
 }
}
@Composable fun Stat(a:String,b:String,c:Color,m:Modifier)=Card(m,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(11.dp)){Text(a,color=Muted,fontSize=11.sp);Text(b,color=c,fontWeight=FontWeight.Bold,fontSize=13.sp)}}
@Composable fun Section(s:String)=Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=10.dp)){Text(s,fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))}
@Composable fun Category(n:String,v:Long,total:Long){Card(Modifier.padding(horizontal=16.dp,vertical=4.dp).fillMaxWidth(),shape=RoundedCornerShape(17.dp)){Column(Modifier.padding(14.dp)){Row{Text(n,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));Text(money(v),fontWeight=FontWeight.Bold)};Spacer(Modifier.height(7.dp));LinearProgressIndicator(progress={(v.toFloat()/total.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(7.dp)),color=Green,trackColor=Mint)}}}

@Composable fun Transactions(txs:List<Tx>){Column{Header();LazyColumn(contentPadding=PaddingValues(16.dp)){if(txs.isEmpty())item{Empty("لا توجد معاملات بعد")};items(txs.sortedByDescending{it.id},key={it.id}){t->Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(17.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=if(t.income)Mint else Color(0xFFFFEFED),shape=CircleShape){Icon(if(t.income)Icons.Default.TrendingUp else Icons.Default.ShoppingCart,null,tint=if(t.income)Green else Red,modifier=Modifier.padding(9.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(t.title,fontWeight=FontWeight.SemiBold);Text("${t.category} • ${t.date}",color=Muted,fontSize=11.sp)};Text((if(t.income)"+ " else "− ")+money(t.amount),color=if(t.income)Green else Red,fontWeight=FontWeight.Bold)}}}}}}
@Composable fun Empty(s:String)=Column(Modifier.fillMaxWidth().padding(50.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.ReceiptLong,null,tint=Muted,modifier=Modifier.size(44.dp));Spacer(Modifier.height(10.dp));Text(s,color=Muted)}

@Composable fun Budget(current:Long,onSave:(Long)->Unit){var v by remember(current){mutableStateOf(current.toString())};Column(Modifier.padding(18.dp)){Text("الميزانية",fontSize=28.sp,fontWeight=FontWeight.ExtraBold);Text("حدد سقف مصروفاتك الشهرية",color=Muted);Spacer(Modifier.height(22.dp));Card(shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(20.dp)){Text("الميزانية الشهرية",fontWeight=FontWeight.Bold);OutlinedTextField(v,{v=it.filter(Char::isDigit)},label={Text("بالدينار الجزائري")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(14.dp));Button(onClick={onSave(v.toLongOrNull()?:current)},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){Text("حفظ الميزانية")}}}}}

@Composable fun Reports(txs:List<Tx>,budget:Long){val inc=txs.filter{it.income}.sumOf{it.amount};val exp=txs.filter{!it.income}.sumOf{it.amount};Column(Modifier.padding(18.dp)){Text("التقارير",fontSize=28.sp,fontWeight=FontWeight.ExtraBold);Text("صورة واضحة عن وضعك المالي",color=Muted);Spacer(Modifier.height(18.dp));Card(shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("ملخص الشهر",fontSize=18.sp,fontWeight=FontWeight.Bold);ReportRow("إجمالي الدخل",inc,Green);ReportRow("إجمالي المصاريف",exp,Red);ReportRow("المتبقي",inc-exp,Green);Spacer(Modifier.height(12.dp));Text("نسبة المصروف من الميزانية",color=Muted);LinearProgressIndicator(progress={(exp.toFloat()/budget.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(12.dp),color=if(exp>budget)Red else Green,trackColor=Mint)}}};Section("أعلى الفئات");txs.filter{!it.income}.groupBy{it.category}.entries.sortedByDescending{it.value.sumOf{t->t.amount}}.take(6).forEach{Category(it.key,it.value.sumOf{t->t.amount},exp)}}}
@Composable fun ReportRow(n:String,v:Long,c:Color)=Row(Modifier.fillMaxWidth().padding(vertical=7.dp)){Text(n,modifier=Modifier.weight(1f),color=Muted);Text(money(v),fontWeight=FontWeight.Bold,color=c)}

@Composable fun More(ctx:Context){Column(Modifier.padding(18.dp)){Text("المزيد",fontSize=28.sp,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(18.dp));Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Deep)){Column(Modifier.padding(22.dp)){Text("دبّرها PRO",color=Orange,fontSize=23.sp,fontWeight=FontWeight.ExtraBold);Text("مزايا أكثر لإدارة أموالك",color=Color.White,modifier=Modifier.padding(vertical=8.dp));listOf("بدون إعلانات","تقارير متقدمة","الديون والأقساط","أهداف الادخار","تصدير PDF","نسخ احتياطي").forEach{Text("✓  $it",color=Color.White,modifier=Modifier.padding(vertical=4.dp))};Spacer(Modifier.height(10.dp));Button(onClick={Toast.makeText(ctx,"سيتم تفعيل PRO في الإصدار المدفوع",Toast.LENGTH_SHORT).show()},colors=ButtonDefaults.buttonColors(containerColor=Orange),modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("ترقية PRO",color=Ink,fontWeight=FontWeight.Bold)}}};Spacer(Modifier.height(14.dp));listOf("الإعدادات","اللغة: العربية","الخصوصية والأمان","المساعدة والدعم").forEach{ListItem(headlineContent={Text(it)},leadingContent={Icon(Icons.Default.ChevronLeft,null,tint=Green)})}}}

@Composable fun EntryDialog(income:Boolean,onDismiss:()->Unit,onSave:(Tx)->Unit){var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var cat by remember{mutableStateOf(if(income)"راتب" else "الطعام")};AlertDialog(onDismissRequest=onDismiss,title={Text(if(income)"إضافة دخل" else "إضافة مصروف")},text={Column{OutlinedTextField(title,{title=it},label={Text("البيان")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(9.dp));OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("المبلغ بالدينار")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(9.dp));OutlinedTextField(cat,{cat=it},label={Text("الفئة")},singleLine=true,modifier=Modifier.fillMaxWidth())}},confirmButton={Button(onClick={onSave(Tx(title=title.ifBlank{if(income)"دخل" else "مصروف"},category=cat.ifBlank{"عام"},amount=amount.toLongOrNull()?:0,income=income))}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})}

@Composable fun BottomBar(cur:Screen,on:(Screen)->Unit){NavigationBar{listOf(Screen.Home to "الرئيسية",Screen.Transactions to "المعاملات",Screen.Budget to "الميزانية",Screen.Reports to "التقارير",Screen.More to "المزيد").forEach{(s,l)->NavigationBarItem(selected=cur==s,onClick={on(s)},icon={Icon(when(s){Screen.Home->Icons.Default.Home;Screen.Transactions->Icons.Default.ReceiptLong;Screen.Budget->Icons.Default.AccountBalanceWallet;Screen.Reports->Icons.Default.BarChart;Screen.More->Icons.Default.MoreHoriz},l)},label={Text(l,fontSize=10.sp)})}}}
